
#include  "led.h"	// ������� led.h ���ͷ�ļ�
void Delay_Ms(uint xms)
{
	uint	i,j; for(i=0;i<xms;i++)
	{
		for(j=0;j<110;j++);
	}	
}
 
void	Display_Led()
{
	uchar	aa,j; aa = 0x7f; for(j=0;j<8;j++)
	{
		P1  = aa;
		aa = _cror_(aa,1);Delay_Ms(500);
	}
}
